import sys
sys.path.append('/work/scratch/huanyu/pycharmprojects/flownet2-tf/src')
from src.dataloader import load_batch
from src.dataset_configs import FLYING_CHAIRS_DATASET_CONFIG
from src.training_schedules import LONG_SCHEDULE
from src.flownet_c.flownet_c import FlowNetC

# Create a new network
net = FlowNetC()

# Load a batch of data
input_a, input_b, flow = load_batch(FLYING_CHAIRS_DATASET_CONFIG, 'sample', net.global_step)

# Train on the data
net.train(
    log_dir='./logs/flownet_c',
    training_schedule=LONG_SCHEDULE,
    input_a=input_a,
    input_b=input_b,
    flow=flow
)
