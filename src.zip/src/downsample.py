import tensorflow as tf

_downsample = tf.load_op_library(
    tf.resource_loader.get_path_to_datafile('/work/scratch/huanyu/pycharmprojects/flownet2-tf/src/ops/build/downsample.so'))


def downsample(tensor, size):
    return _downsample.downsample(tensor, size)
