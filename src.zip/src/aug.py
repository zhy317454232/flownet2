import numpy as np
import matplotlib.pyplot as plt
import sys
import cv2

sys.path.append('/work/scratch/huanyu/pycharmprojects/flownet2-tf')
import gryds
import scipy
plt.rcParams['image.cmap'] = 'gray'
import src.flowlib

def draw_hsv(flow):
    h, w = flow.shape[1:]
    fy, fx = flow[0,:,:], flow[1,:,:]
    ang = np.arctan2(fy, fx) + np.pi ##########
    v = np.sqrt(fx*fx+fy*fy)
    hsv = np.zeros((h, w, 3), np.uint8)
    hsv[...,0] = ang*(180/np.pi/2)   #############
    hsv[...,1] = 255
    #hsv[...,2] = np.minimum(v*1000, 255)   ############
    hsv[..., 2] = cv2.normalize(v, None, 0, 255, cv2.NORM_MINMAX)
    bgr = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
    return bgr

def get_flow(img, trans_img):
    return img - trans_img

original_image = plt.imread('/work/scratch/huanyu/pycharmprojects/flownet2-tf/data/tra_hela01_converted/man_track000.tif')
image = original_image.copy()
# image[10::20] = 150
# image[11::20] = 150
# image[:, 10::20] = 150
# image[:, 11::20] = 150


# translation
a_translation = gryds.TranslationTransformation([0, 0.1])
an_image_interpolator = gryds.Interpolator(image, order=0, cval=0, mode='constant')
a_translation_image = an_image_interpolator.transform(a_translation, order=0)



# rotation
a_rotation1 = gryds.AffineTransformation(
    ndim=2,
    angles=[np.pi/4.], # List of angles (for 3D transformations you need a list of 3 angles).
    center=[0.5, 0.5]  # Center of rotation.
)

a_grid = gryds.Grid(image.shape)
transformed_grid = a_grid.transform(a_rotation1)
a_rotation1_image = an_image_interpolator.transform(a_rotation1, order=0)
#a_rotation1_image = an_image_interpolator.resample(transformed_grid)
fig10, ax10 = plt.subplots(1, 2)
ax10[0].imshow(original_image)
ax10[1].imshow(a_rotation1_image)
ax10[0].set_title('original image')
ax10[1].set_title('translated image')
plt.show()

displacement_field = transformed_grid.grid - a_grid.grid   # displacement for grid, opposite from the image
#print(displacement_field)
a=np.where(image == 0)
d1=np.zeros(np.shape(displacement_field))
d1[:]=displacement_field
for k in range(len(a[0])):
    d1[0][a[0][k]][a[1][k]] = 0
    d1[1][a[0][k]][a[1][k]] = 0

#print(displacement_field)
cv2.imwrite('hsv_ro.png', cv2.cvtColor(draw_hsv(d1), cv2.COLOR_BGR2RGB))
fig11, ax11 = plt.subplots(1, 2)
ax11[0].imshow(a_rotation1_image)
ax11[1].imshow(draw_hsv(d1))
ax11[0].set_title('translated image')
ax11[1].set_title('hsv_rotation')
plt.show()

fig12, ax12 = plt.subplots(1, 2)

ax12[0].imshow(**gryds.dvf_show(displacement_field[0]))
ax12[1].imshow(**gryds.dvf_show(displacement_field[1]))
ax12[0].set_title('$u_x$')
ax12[1].set_title('$u_y$')
plt.show()


# affine transformations
a_affine_transformation = gryds.AffineTransformation(
    ndim=2,
    angles=[np.pi/10.], # the rotation angle
    scaling=[1.2, 1.2], # the anisotropic scaling
    shear_matrix=[[1, 0.5], [0, 1]], # shearing matrix
    translation=[0., 0.], # translation
    center=[0.5, 0.5] # center of rotation
)
a_grid = gryds.Grid(image.shape)
transformed_grid = a_grid.transform(a_affine_transformation)
a_affine_image = an_image_interpolator.transform(a_affine_transformation, order=0)

fig20, ax20 = plt.subplots(1, 2)
ax20[0].imshow(original_image)
ax20[1].imshow(a_affine_image)
ax20[0].set_title('original image')
ax20[1].set_title('translated image')
plt.show()

displacement_field = transformed_grid.grid - a_grid.grid   # displacement for grid, opposite from the image
#print(displacement_field)
a=np.where(image == 0)
d1=np.zeros(np.shape(displacement_field))
d1[:]=displacement_field
for k in range(len(a[0])):
    d1[0][a[0][k]][a[1][k]] = 0
    d1[1][a[0][k]][a[1][k]] = 0

#print(displacement_field)
cv2.imwrite('hsv_aff.png', cv2.cvtColor(draw_hsv(d1), cv2.COLOR_BGR2RGB))
fig21, ax21 = plt.subplots(1, 2)
ax21[0].imshow(a_affine_image)
ax21[1].imshow(draw_hsv(d1))
ax21[0].set_title('translated image')
ax21[1].set_title('hsv_affine')
plt.show()

fig22, ax22 = plt.subplots(1, 2)

ax22[0].imshow(**gryds.dvf_show(displacement_field[0]))
ax22[1].imshow(**gryds.dvf_show(displacement_field[1]))
ax22[0].set_title('$u_x$')
ax22[1].set_title('$u_y$')

# displacement_field =get_flow(image, a_translated_image)
# cv2.imwrite('opticalhsv.png', draw_hsv(displacement_field))
# fig2, ax2 = plt.subplots(1, 2)
# ax2[0].imshow(**gryds.dvf_show(displacement_field[0]))
# ax2[1].imshow(**gryds.dvf_show(displacement_field[1]))
# ax2[0].set_title('$u_x$')
# ax2[1].set_title('$u_y$')
plt.show()


# deformable transformation
disp_i = np.array([
    [0.04, 0.02, 0.04],
    [-0.04, 0.01, -0.04],
    [-0.04, -0.01, -0.04]
])
disp_j = np.array([
    [0.04, -0.03, -0.05],
    [0.02, 0.03, 0.05],
    [0.02, -0.04, -0.05]
])

a_bspline_transformation = gryds.BSplineTransformation([disp_i, disp_j], mode='constant')
a_grid = gryds.Grid(image.shape)
transformed_grid = a_grid.transform(a_bspline_transformation)
a_deformed_image = an_image_interpolator.transform(a_bspline_transformation, order=0)

fig30, ax30 = plt.subplots(1, 2)
ax30[0].imshow(original_image)
ax30[1].imshow(a_deformed_image)
ax30[0].set_title('original image')
ax30[1].set_title('translated image')
plt.show()

displacement_field = transformed_grid.grid - a_grid.grid   # displacement for grid, opposite from the image
#print(displacement_field)
a=np.where(image == 0)
d1=np.zeros(np.shape(displacement_field))
d1[:]=displacement_field
for k in range(len(a[0])):
    d1[0][a[0][k]][a[1][k]] = 0
    d1[1][a[0][k]][a[1][k]] = 0

#print(displacement_field)
cv2.imwrite('hsv_de.png', cv2.cvtColor(draw_hsv(d1), cv2.COLOR_BGR2RGB))
fig31, ax31 = plt.subplots(1, 2)
ax31[0].imshow(a_deformed_image)
ax31[1].imshow(draw_hsv(d1))
ax31[0].set_title('translated image')
ax31[1].set_title('hsv_deformable')
plt.show()

fig32, ax32 = plt.subplots(1, 2)
ax32[0].imshow(**gryds.dvf_show(displacement_field[0]))
ax32[1].imshow(**gryds.dvf_show(displacement_field[1]))
ax32[0].set_title('$u_x$')
ax32[1].set_title('$u_y$')
plt.show()


# combining transformations
composed = gryds.ComposedTransformation(a_bspline_transformation, a_rotation1, a_translation)
a_grid = gryds.Grid(image.shape)
transformed_grid = a_grid.transform(composed)
twice_transformed_image = an_image_interpolator.transform(composed, order=0, mode='constant')

fig40, ax40 = plt.subplots(1, 2)
ax40[0].imshow(original_image)
ax40[1].imshow(twice_transformed_image)
ax40[0].set_title('original image')
ax40[1].set_title('translated image')
plt.show()

displacement_field = transformed_grid.grid - a_grid.grid   # displacement for grid, opposite from the image
#print(displacement_field)
a=np.where(image == 0)
d1=np.zeros(np.shape(displacement_field))
d1[:]=displacement_field
for k in range(len(a[0])):
    d1[0][a[0][k]][a[1][k]] = 0
    d1[1][a[0][k]][a[1][k]] = 0

#print(displacement_field)
cv2.imwrite('hsv_com.png', cv2.cvtColor(draw_hsv(d1), cv2.COLOR_BGR2RGB))
fig41, ax41 = plt.subplots(1, 2)
ax41[0].imshow(twice_transformed_image)
ax41[1].imshow(draw_hsv(d1))
ax41[0].set_title('translated image')
ax41[1].set_title('hsv_combine')
plt.show()

fig42, ax42 = plt.subplots(1, 2)
ax42[0].imshow(**gryds.dvf_show(displacement_field[0]))
ax42[1].imshow(**gryds.dvf_show(displacement_field[1]))
ax42[0].set_title('$u_x$')
ax42[1].set_title('$u_y$')
plt.show()

d1 = d1.transpose(1, 2, 0)
img = src.flowlib.flow_to_image(d1)
plt.imshow(img)
plt.show()


src.flowlib.write_flow(d1, '/work/scratch/huanyu/pycharmprojects/flownet2-tf/data/d1.flo')
a = src.flowlib.read_flow('/work/scratch/huanyu/pycharmprojects/flownet2-tf/data/d1.flo')
b = src.flowlib.read_flow('/work/scratch/huanyu/pycharmprojects/flownet2-tf/data/samples/0flow.flo')
