# Pythono3 code to rename multiple
# files in a directory or folder

import os
import scipy.io as sio
import sys
sys.path.append('/work/scratch/huanyu/pycharmprojects/flownet2-tf')
from src.flowlib import write_flow
import numpy as np

# Function to rename multiple files
def con_fname():
    i = 0
    path_list = os.listdir('/work/scratch/huanyu/pycharmprojects/flownet2-tf/data/01_02_part')
    path_list.sort()
    print(path_list)

    for filename in path_list:
        dst = 't' + '%05d' % i + '.tif'
        src = '/work/scratch/huanyu/pycharmprojects/flownet2-tf/data/01_02_part/' + filename
        dst = '/work/scratch/huanyu/pycharmprojects/flownet2-tf/data/01_02_part/' + dst

        # rename() function will rename all the files
        os.rename(src, dst)
        i += 1

def mat2flo():
    i = 0
    path_list = os.listdir('/work/scratch/huanyu/pycharmprojects/flownet2-tf/data/01_02_pflow')
    path_list.sort()
    print(path_list)

    for filename in path_list:
        dst = 'f' + '%05d' % (i+1) + '.flo'
        src = '/work/scratch/huanyu/pycharmprojects/flownet2-tf/data/01_02_pflow/' + filename
        dst = '/work/scratch/huanyu/pycharmprojects/flownet2-tf/data/01_02_pflo/' + dst
        data_dict = sio.loadmat(src)
        data = np.dstack((data_dict['flowFieldX'], data_dict['flowFieldX']))
        write_flow(data, dst)
        i += 1



def main():
    #con_fname()
    mat2flo()


# Driver Code
if __name__ == '__main__':
    # Calling main function
    main()
