#! /work/scratch/huanyu/miniconda3/envs/flownet3.6/bin/python
import sys
sys.path.append('/work/scratch/huanyu/pycharmprojects/flownet2-tf')
from src.dataloader import load_batch
from src.dataset_configs import FLYING_CHAIRS_DATASET_CONFIG
from src.training_schedules import LONG_SCHEDULE
from src.flownet2.flownet2 import FlowNet2

# Create a new network
net = FlowNet2()

# Load a batch of data
input_a, input_b, flow = load_batch(FLYING_CHAIRS_DATASET_CONFIG, 'sample', net.global_step)

# Train on the data
net.train(
    log_dir='/work/scratch/huanyu/pycharmprojects/flownet2-tf/logs/flownet_2',
    training_schedule=LONG_SCHEDULE,
    input_a=input_a,
    input_b=input_b,
    flow=flow,
    # Load trained weights for CSS and SD parts of network
    checkpoints={
        '/work/scratch/huanyu/pycharmprojects/flownet2-tf/checkpoints/FlowNetCSS-ft-sd/flownet-CSS-ft-sd.ckpt-0': ('FlowNet2/FlowNetCSS', 'FlowNet2'),
        '/work/scratch/huanyu/pycharmprojects/flownet2-tf/checkpoints/FlowNetSD/flownet-SD.ckpt-0': ('FlowNet2/FlowNetSD', 'FlowNet2')
    }
)
